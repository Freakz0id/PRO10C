var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["af33cf0a-d578-4f71-b731-296d599c208a","c7f7c864-a096-4270-9622-bdb3841dc58d","a7264815-f2a9-46d0-b819-dff3279352c2"],"propsByKey":{"af33cf0a-d578-4f71-b731-296d599c208a":{"name":"b1","sourceUrl":null,"frameSize":{"x":172,"y":200},"frameCount":1,"looping":true,"frameDelay":12,"version":"FU6UsUa.Ccd4y_ih6JAb7l7Kb64sidOr","categories":["buildings"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":172,"y":200},"rootRelativePath":"assets/af33cf0a-d578-4f71-b731-296d599c208a.png"},"c7f7c864-a096-4270-9622-bdb3841dc58d":{"name":"fondo","sourceUrl":"assets/api/v1/animation-library/gamelab/OGMmhuYDozWZhjtNHQkjhdvs2Ge_Q0UF/category_backgrounds/city.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"OGMmhuYDozWZhjtNHQkjhdvs2Ge_Q0UF","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/OGMmhuYDozWZhjtNHQkjhdvs2Ge_Q0UF/category_backgrounds/city.png"},"a7264815-f2a9-46d0-b819-dff3279352c2":{"name":"luna","sourceUrl":null,"frameSize":{"x":214,"y":200},"frameCount":1,"looping":true,"frameDelay":12,"version":"SO4C3LpjLgJl61apoHIg7TOPsOj1XMWY","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":214,"y":200},"rootRelativePath":"assets/a7264815-f2a9-46d0-b819-dff3279352c2.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var escenario=createSprite(200,300)
escenario.setAnimation("fondo")

var personaje=createSprite(200,300)
personaje.setAnimation("b1")

function draw() {
  drawSprites();
}

  

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
